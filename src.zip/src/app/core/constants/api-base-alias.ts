export enum ApiBaseAlias {
  AUTH = 'AUTH',
  BASE = 'BASE',
}
