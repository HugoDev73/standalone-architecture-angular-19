export const environment = {

    auth: 'https://dev-auth.api.com',
    base: 'https://dev-products.api.com',
};
